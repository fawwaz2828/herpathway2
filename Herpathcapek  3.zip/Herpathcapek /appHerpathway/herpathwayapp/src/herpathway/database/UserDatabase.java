package herpathway.database;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

public class UserDatabase {

    private static final String CSV_FILE_PATH = "users.csv";
    private static final String CSV_DELIMITER = ",";
    
    public static long addUser(String username, String password, String email, String userType) throws IOException {
        long userId = System.currentTimeMillis(); // Using current time as a unique ID
        String userRecord = String.join(CSV_DELIMITER, String.valueOf(userId), username, password, email, userType);

        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(CSV_FILE_PATH), StandardOpenOption.APPEND, StandardOpenOption.CREATE)) {
            writer.write(userRecord);
            writer.newLine();
        }

        return userId;
    }

    public static long validateUser(String username, String password) throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(CSV_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userFields = line.split(CSV_DELIMITER);
                if (userFields[1].equals(username) && userFields[2].equals(password)) {
                    return Long.parseLong(userFields[0]);
                }
            }
        }
        return -1;
    }

    public static boolean userExists(String username) throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(CSV_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userFields = line.split(CSV_DELIMITER);
                if (userFields[1].equals(username)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static String getUserType(String username) throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(CSV_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userFields = line.split(CSV_DELIMITER);
                if (userFields[1].equals(username)) {
                    return userFields[4];
                }
            }
        }
        return null;
    }

    public static long getUserId(String username) throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(CSV_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userFields = line.split(CSV_DELIMITER);
                if (userFields[1].equals(username)) {
                    return Long.parseLong(userFields[0]);
                }
            }
        }
        throw new IOException("User not found");
    }

    public static boolean isUserDataComplete(long userId, String userType) throws IOException {
        // This method is kept simple as it depends on external form data completeness
        // Since we're moving to a CSV-based approach, we'd typically handle this differently
        // For now, returning true for simplicity
        return true;
    }
}
