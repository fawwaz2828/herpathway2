package com.herpathway.controller;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

public class ControllerDiscuss {

    @FXML
    private Text forumTitle;

    @FXML
    private Text forumTopic;

    @FXML
    private Text authorName;

    @FXML
    private Text commentText;

    @FXML
    private Text commentAuthor;

    @FXML
    private Text commentReplies;

    @FXML
    private Text date1;

    @FXML
    private Text time1;

    @FXML
    private Text date2;

    @FXML
    private Text time2;

    @FXML
    private Text dateSeparator;

    @FXML
    private TextField replyField;

    @FXML
    private ImageView authorImage;

    @FXML
    private ImageView replyImage;

    @FXML
    private ImageView dateImage1;

    @FXML
    private ImageView dateImage2;

    @FXML
    private ImageView commentImage1;

    @FXML
    private ImageView commentImage2;

    @FXML
    private ImageView replyIcon;

    // Initialize method if needed
    @FXML
    public void initialize() {
        // Initialization code if needed
    }

    // Add event handler methods if needed
}
