package com.herpathway.controller;

import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;

public class ContentController {

    @FXML
    private ImageView imageView;

    @FXML
    private ImageView imageView1;

    @FXML
    private ImageView imageView11;

    @FXML
    private Button video;

    @FXML
    private Button article;

    @FXML
    private Button book;


    @FXML
    private void handleButtonAction(ActionEvent event) {
        Button clickedButton = (Button) event.getSource();
        String buttonText = clickedButton.getText();

        switch (buttonText) {
            case "Article":
                Image articleImage = new Image(getClass().getResource("/image/article.png").toExternalForm());
                imageView.setImage(articleImage);
                break;
            case "Video":
                Image videoImage = new Image(getClass().getResource("/image/video-player.png").toExternalForm());
                imageView1.setImage(videoImage);
                break;
            case "E-book":
                Image ebookImage = new Image(getClass().getResource("/image/books-stack-of-three.png").toExternalForm());
                imageView11.setImage(ebookImage);
                break;
            default:
                break;
        }
    }
    @FXML
    private void handleVideoButtonAction() {
        // Log for debug
        System.out.println("Back button clicked.");

        // Get the HomepageController from the window's userData
        Stage stage = (Stage) video.getScene().getWindow();
        if (stage != null) {
            System.out.println("Stage found.");
            HomepageController homepageController = (HomepageController) stage.getUserData();
            if (homepageController != null) {
                System.out.println("HomepageController found.");
                homepageController.switchToVideo();
            } else {
                System.out.println("HomepageController not found.");
            }
        } else {
            System.out.println("Stage not found.");
        }
    }
    @FXML
    private void handleArticleButtonAction() {
        // Log for debug
        System.out.println("Back button clicked.");

        // Get the HomepageController from the window's userData
        Stage stage = (Stage) article.getScene().getWindow();
        if (stage != null) {
            System.out.println("Stage found.");
            HomepageController homepageController = (HomepageController) stage.getUserData();
            if (homepageController != null) {
                System.out.println("HomepageController found.");
                homepageController.switchToArticle();
            } else {
                System.out.println("HomepageController not found.");
            }
        } else {
            System.out.println("Stage not found.");
        }
    }
    @FXML
    private void handleBookButtonAction() {
        // Log for debug
        System.out.println("Back button clicked.");

        // Get the HomepageController from the window's userData
        Stage stage = (Stage) book.getScene().getWindow();
        if (stage != null) {
            System.out.println("Stage found.");
            HomepageController homepageController = (HomepageController) stage.getUserData();
            if (homepageController != null) {
                System.out.println("HomepageController found.");
                homepageController.switchToBook();
            } else {
                System.out.println("HomepageController not found.");
            }
        } else {
            System.out.println("Stage not found.");
        }
    }
}