package com.herpathway.controller;

import com.herpathway.model.MentorData;
import com.herpathway.session.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;

import java.io.File;
import java.io.IOException;
import java.sql.*;

public class HomepageController {

    private static HomepageController instance;

    @FXML
    private VBox contentArea;

    @FXML
    private Label profileNameLabel;

    @FXML
    private ImageView profileImageView;

    public HomepageController() {
        instance = this;
    }

    public static HomepageController getInstance() {
        return instance;
    }

    @FXML
    private void handleMentorButtonAction() {
        switchContent("MentorMenu.fxml");
    }

    @FXML
    private void handleSessionButtonAction() {
        switchContent("MenteeChatSession.fxml");
    }

    @FXML
    private void handleForumButtonAction() {
        switchContent("Forum.fxml");
    }

    @FXML
    private void handleContentButtonAction() {
        switchContent("Content.fxml");
    }

    @FXML
    private void handleProfileButtonAction() {
        switchContent("UserProfileView.fxml");
    }

    @FXML
    private void handleChatButtonAction() {
        long userId = SessionManager.getInstance().getCurrentUserId();
        if (isApplicationAccepted(userId)) {
            switchToChatSession(userId);
        } else {
            showAlert("Access Denied", "You can access the chat session only after your application has been accepted by a mentor.");
        }
    }

    @FXML
    public void initialize() {
        if (contentArea == null) {
            System.out.println("contentArea is null.");
        } else {
            System.out.println("contentArea is not null.");
        }

        loadUserProfile();
        handleMentorButtonAction(); // Default to MentorMenu on initialize
    }

    public void switchContent(String fxmlFile) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/" + fxmlFile));
            Parent newLoadedPane = loader.load();

            if (fxmlFile.equals("UserProfileView.fxml")) {
                UserProfileController controller = loader.getController();
                controller.init();
            }

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading content: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void switchToChatSession(long menteeId) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/MenteeChatSession.fxml"));
            Parent newLoadedPane = loader.load();

            MenteeChatSessionController controller = loader.getController();
            controller.setMenteeId(menteeId);
            controller.setMentorId(getAssignedMentorId(menteeId));
            controller.setSenderId(SessionManager.getInstance().getCurrentUserId());
            controller.loadChatHistory();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "An error occurred while loading the chat session: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private boolean isApplicationAccepted(long userId) {
        String url = "jdbc:mysql://localhost:3306/herpath";
        String user = "root";
        String password = "mochimochi53";

        String query = "SELECT status FROM form_Mentee WHERE userId = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setLong(1, userId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String status = rs.getString("status");
                return "Accepted".equals(status);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    private long getAssignedMentorId(long menteeId) {
        String url = "jdbc:mysql://localhost:3306/herpath";
        String user = "root";
        String password = "mochimochi53";

        String query = "SELECT mentorId FROM mentor_assignment WHERE menteeId = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setLong(1, menteeId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getLong("mentorId");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0L; // Replace this with actual logic
    }

    private void loadUserProfile() {
        long userId = SessionManager.getInstance().getCurrentUserId();
        if (userId == 0) {
            showAlert("Load Error", "User ID not set.");
            return;
        }

        String query = "SELECT displayName, profilePicturePath FROM form_Mentee WHERE userId = ?";
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/herpath", "root", "mochimochi53");
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setLong(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                String displayName = resultSet.getString("displayName");
                String profilePicturePath = resultSet.getString("profilePicturePath");

                profileNameLabel.setText(displayName);

                if (profilePicturePath != null && !profilePicturePath.isEmpty()) {
                    File profilePictureFile = new File(profilePicturePath);
                    if (profilePictureFile.exists()) {
                        Image profileImage = new Image(profilePictureFile.toURI().toString());
                        profileImageView.setImage(profileImage);
                    } else {
                        profileImageView.setImage(null);
                    }
                } else {
                    profileImageView.setImage(null);
                }
            }
        } catch (SQLException e) {
            showAlert("Database Error", "Error fetching user profile: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void switchToUserProfile() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/UserProfileView.fxml"));
            Parent newLoadedPane = loader.load();

            UserProfileController controller = loader.getController();
            controller.init();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading user profile: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void switchToMentorProfile(MentorData mentor) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/ProfilMentorView.fxml"));
            Parent newLoadedPane = loader.load();
    
            ProfilMentorController controller = loader.getController();
            controller.setMentorData(mentor);
    
            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading mentor profile: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void switchToMentorshipQuestion() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/MentorshipQuestion.fxml"));
            Parent newLoadedPane = loader.load();

            MentorshipQuestionController controller = loader.getController();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading Mentorship Question: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void switchToMentorMenu() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/MentorMenu.fxml"));
            Parent newLoadedPane = loader.load();

            MentorMenuController controller = loader.getController();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading mentor menu: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public void switchToThread() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/thread.fxml"));
            Parent newLoadedPane = loader.load();

            ControllerThread controller = loader.getController();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading mentor menu: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void switchToThread2() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/thread2.fxml"));
            Parent newLoadedPane = loader.load();

            ControllerThread2 controller = loader.getController();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading mentor menu: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void switchToScience() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/science1.fxml"));
            Parent newLoadedPane = loader.load();

            ControllerScience1 controller = loader.getController();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading mentor menu: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public void switchToTeknologi() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/teknologi1.fxml"));
            Parent newLoadedPane = loader.load();

            ControllerTeknologi controller = loader.getController();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading mentor menu: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public void switchToPost() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/post.fxml"));
            Parent newLoadedPane = loader.load();

            ControllerPost controller = loader.getController();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading mentor menu: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void switchToDiscuss() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/discuss.fxml"));
            Parent newLoadedPane = loader.load();

            ControllerDiscuss controller = loader.getController();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading mentor menu: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public void switchToVideo() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/Video.fxml"));
            Parent newLoadedPane = loader.load();

            Video controller = loader.getController();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading mentor menu: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public void switchToArticle() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/Article.fxml"));
            Parent newLoadedPane = loader.load();

            Article controller = loader.getController();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading mentor menu: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public void switchToBook() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/Book.fxml"));
            Parent newLoadedPane = loader.load();

            Book controller = loader.getController();

            contentArea.getChildren().clear();
            contentArea.getChildren().add(newLoadedPane);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading mentor menu: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    
    



}
