package com.herpathway.controller;


import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ControllerPost {

    @FXML
    private Button post1;

    @FXML
    private Button Discuss1;

    @FXML
    private Button status1;

    @FXML
    private ImageView imagePost;

    @FXML
    private ImageView imageDiscuss;

    @FXML
    private ImageView imageStatus;

    @FXML
    private AnchorPane shape1;

    @FXML
    private Text text1;

    @FXML
    private Text text2;

    @FXML
    private Button discuss;

    @FXML
    void HandlePost(ActionEvent event) {
        // Implementasi logika untuk button "Post"
        System.out.println("Button 'Post' clicked!");
    }

    @FXML
    void HandleDiscuss(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("discuss.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));

            // Menutup scene saat ini (opsional, tergantung dari kebutuhan aplikasi Anda)
            Stage currentStage = (Stage) Discuss1.getScene().getWindow();
            currentStage.close();

            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void HandleStatus1(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("status.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));

            // Menutup scene saat ini (opsional, tergantung dari kebutuhan aplikasi Anda)
            Stage currentStage = (Stage) Discuss1.getScene().getWindow();
            currentStage.close();

            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleDiscussButtonAction() {
        // Log for debug
        System.out.println("Back button clicked.");

        // Get the HomepageController from the window's userData
        Stage stage = (Stage) discuss.getScene().getWindow();
        if (stage != null) {
            System.out.println("Stage found.");
            HomepageController homepageController = (HomepageController) stage.getUserData();
            if (homepageController != null) {
                System.out.println("HomepageController found.");
                homepageController.switchToDiscuss();
            } else {
                System.out.println("HomepageController not found.");
            }
        } else {
            System.out.println("Stage not found.");
        }
    }
    
}    

