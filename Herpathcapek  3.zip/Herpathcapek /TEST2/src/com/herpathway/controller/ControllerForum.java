package com.herpathway.controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.Button;


public class ControllerForum {

    @FXML
    private AnchorPane box1;

    @FXML
    private ImageView image1;

    @FXML
    private AnchorPane shape2;

    @FXML
    private Text text4;

    @FXML
    private Button open1;

    @FXML
    private ImageView image2;

    @FXML
    private AnchorPane shape1;

    @FXML
    private Text text2;

    @FXML
    private AnchorPane shape3;


    @FXML
    private Text text6;

    @FXML
    private Button join2;

    @FXML
    private AnchorPane shape5;

    @FXML
    private Text text7;

    @FXML
    private ImageView image3;

    @FXML
    private TextField textField1;

    @FXML
    private ImageView search;

    @FXML
    private Button thread;
    @FXML
    private Button thread2;


    @FXML
    private void search(ActionEvent event) {
        // Implementasi logika untuk pencarian
        String searchText = textField1.getText();
        System.out.println("Search text: " + searchText);
    }
    @FXML
    private void handleThreadButtonAction() {
        // Log for debug
        System.out.println("Back button clicked.");

        // Get the HomepageController from the window's userData
        Stage stage = (Stage) thread.getScene().getWindow();
        if (stage != null) {
            System.out.println("Stage found.");
            HomepageController homepageController = (HomepageController) stage.getUserData();
            if (homepageController != null) {
                System.out.println("HomepageController found.");
                homepageController.switchToThread();
            } else {
                System.out.println("HomepageController not found.");
            }
        } else {
            System.out.println("Stage not found.");
        }

    }
    @FXML
    private void handleThreadButtonAction2() {
        // Log for debug
        System.out.println("Back button clicked.");

        // Get the HomepageController from the window's userData
        Stage stage = (Stage) thread2.getScene().getWindow();
        if (stage != null) {
            System.out.println("Stage found.");
            HomepageController homepageController = (HomepageController) stage.getUserData();
            if (homepageController != null) {
                System.out.println("HomepageController found.");
                homepageController.switchToThread2();
            } else {
                System.out.println("HomepageController not found.");
            }
        } else {
            System.out.println("Stage not found.");
        }
    }
}




