package com.herpathway.controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class ControllerThread {

    @FXML
    private AnchorPane anchorpane2;

    @FXML
    private AnchorPane pane1;

    @FXML
    private ImageView gambar1;

    @FXML
    private Text text1;

    @FXML
    private Text text2;

    @FXML
    private Text text3;

    @FXML
    private Text text4;

    @FXML
    private Text text5;

    @FXML
    private Text text6;

    @FXML
    private Text text7;

    @FXML
    private Text text8;

    @FXML
    private Text text9;

    @FXML
    private Text text10;

    @FXML
    private Line line1;

    @FXML
    private Line line2;

    @FXML
    private Circle line3;

    @FXML
    private Circle line4;

    @FXML
    private ImageView shape1;

    @FXML
    private ImageView shape2;

    @FXML
    private ImageView shape3;

    @FXML
    private ImageView shape4;

    @FXML
    private ImageView shape5;

    @FXML
    private ImageView shape6;

    @FXML
    private ImageView shape7;

    @FXML
    private ImageView shape8;

    @FXML
    private ImageView shape9;

    @FXML
    private ImageView shape10;

    @FXML
    private Button buttonForum;

    @FXML
    private Button buttonForum1;

    @FXML
    private Button science;

    @FXML
    private Button teknologi;
    


    @FXML
    private void joinThread1(ActionEvent event) {
        HomepageController.getInstance().switchContent("science1.fxml");
    }

    @FXML
    private void joinThread2(ActionEvent event) {
        HomepageController.getInstance().switchContent("teknologi.fxml");
    }


    
    @FXML
    private void handleScienceButtonAction() {
        // Log for debug
        System.out.println("Back button clicked.");

        // Get the HomepageController from the window's userData
        Stage stage = (Stage) science.getScene().getWindow();
        if (stage != null) {
            System.out.println("Stage found.");
            HomepageController homepageController = (HomepageController) stage.getUserData();
            if (homepageController != null) {
                System.out.println("HomepageController found.");
                homepageController.switchToScience();
            } else {
                System.out.println("HomepageController not found.");
            }
        } else {
            System.out.println("Stage not found.");
        }
    }

    @FXML
    private void handleTeknologiButtonAction() {
        // Log for debug
        System.out.println("Back button clicked.");

        // Get the HomepageController from the window's userData
        Stage stage = (Stage) teknologi.getScene().getWindow();
        if (stage != null) {
            System.out.println("Stage found.");
            HomepageController homepageController = (HomepageController) stage.getUserData();
            if (homepageController != null) {
                System.out.println("HomepageController found.");
                homepageController.switchToTeknologi();
            } else {
                System.out.println("HomepageController not found.");
            }
        } else {
            System.out.println("Stage not found.");
        }
    }

}
