package com.herpathway.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.herpathway.model.MentorData;
import com.herpathway.session.SessionManager;

public class MentorshipQuestionController {

    @FXML
    private RadioButton veryExperiencedRadioButton;

    @FXML
    private RadioButton experiencedRadioButton;

    @FXML
    private RadioButton neutralRadioButton;

    @FXML
    private RadioButton inexperiencedRadioButton;

    @FXML
    private RadioButton veryInexperiencedRadioButton;

    @FXML
    private CheckBox networkingCheckBox;

    @FXML
    private CheckBox learningSkillsCheckBox;

    @FXML
    private CheckBox careerAdviceCheckBox;

    @FXML
    private CheckBox personalDevelopmentCheckBox;

    @FXML
    private TextArea suggestionsTextArea;

    @FXML
    private VBox parentVBox;

    @FXML
    private Button backButton;

    @FXML
    private Button viewProfileButton;

    @FXML
    private Button mentorMenuButton; // Define the new button

    private ToggleGroup experienceLevelToggleGroup;

    @FXML
    public void initialize() {
        experienceLevelToggleGroup = new ToggleGroup();
        veryExperiencedRadioButton.setToggleGroup(experienceLevelToggleGroup);
        experiencedRadioButton.setToggleGroup(experienceLevelToggleGroup);
        neutralRadioButton.setToggleGroup(experienceLevelToggleGroup);
        inexperiencedRadioButton.setToggleGroup(experienceLevelToggleGroup);
        veryInexperiencedRadioButton.setToggleGroup(experienceLevelToggleGroup);

        long userId = SessionManager.getInstance().getCurrentUserId();
        if (userId != 0) {
            System.out.println("ID user diterima: " + userId);
        } else {
            System.out.println("ID user tidak diterima.");
            showAlert("Kesalahan", "ID user tidak dapat diambil.");
        }
    }

    @FXML
    private void handleSubmitButtonAction() {
        if (!isFormValid()) {
            return;
        }

        long userIdMentee = SessionManager.getInstance().getCurrentUserId();
        long userIdMentor = SessionManager.getInstance().getCurrentMentorId();
        if (userIdMentee == 0 || userIdMentor == 0) {
            showAlert("Kesalahan", "ID pengguna atau mentor tidak dapat diambil.");
            return;
        }

        String experienceLevelMentee = getSelectedExperienceLevel();
        String beneficialAspects = getSelectedBeneficialAspects();
        String suggestions = suggestionsTextArea.getText();

        saveToDatabase(userIdMentee, userIdMentor, experienceLevelMentee, beneficialAspects, suggestions);

        clearForm();

        showAlert("Pengiriman Formulir Berhasil", "Respons Anda telah berhasil dikirim.");

        showApprovalWaitAlert();
    }

    @FXML
    private void handleMentorMenuButtonAction() {
        HomepageController homepageController = HomepageController.getInstance();
        homepageController.switchToMentorMenu();
    }

    private boolean isFormValid() {
        if (experienceLevelToggleGroup.getSelectedToggle() == null) {
            showAlert("Pengiriman Formulir Gagal", "Silakan pilih tingkat pengalaman Anda.");
            return false;
        }

        if (!networkingCheckBox.isSelected() && !learningSkillsCheckBox.isSelected() &&
                !careerAdviceCheckBox.isSelected() && !personalDevelopmentCheckBox.isSelected()) {
            showAlert("Pengiriman Formulir Gagal", "Silakan pilih setidaknya satu aspek yang bermanfaat.");
            return false;
        }

        return true;
    }

    private void saveToDatabase(long userIdMentee, long userIdMentor, String experienceLevelMentee, String beneficialAspects, String suggestions) {
        String url = "jdbc:mysql://localhost:3306/herpath";
        String user = "root";
        String password = "mochimochi53";

        String createTableSQL = "CREATE TABLE IF NOT EXISTS kuisioner (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                "userIdMentee BIGINT NOT NULL, " +
                "userIdMentor BIGINT NOT NULL, " +
                "experience_level_mentee VARCHAR(50) NOT NULL, " +
                "beneficial_aspects TEXT, " +
                "suggestions TEXT, " +
                "FOREIGN KEY (userIdMentee) REFERENCES User(id), " +
                "FOREIGN KEY (userIdMentor) REFERENCES User(id)" +
                ")";

        String insertSQL = "INSERT INTO kuisioner (userIdMentee, userIdMentor, experience_level_mentee, beneficial_aspects, suggestions) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            stmt.execute(createTableSQL);

            pstmt.setLong(1, userIdMentee);
            pstmt.setLong(2, userIdMentor);
            pstmt.setString(3, experienceLevelMentee);
            pstmt.setString(4, beneficialAspects);
            pstmt.setString(5, suggestions);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Data entry failed, no rows are affected");
            }

            showAlert("Data Saved Successfully", "Your data has been saved successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("SQL error: " + e.getMessage());
            showAlert("Database error", "Failed to save data. Please try again later.");
        }
    }

    private String getSelectedExperienceLevel() {
        RadioButton selectedRadioButton = (RadioButton) experienceLevelToggleGroup.getSelectedToggle();
        if (selectedRadioButton != null) {
            return selectedRadioButton.getText();
        }
        return "";
    }

    private String getSelectedBeneficialAspects() {
        StringBuilder selectedAspects = new StringBuilder();
        if (networkingCheckBox.isSelected()) {
            selectedAspects.append("Networking opportunities\n, ");
        }
        if (learningSkillsCheckBox.isSelected()) {
            selectedAspects.append("Learning new skills\n, ");
        }
        if (careerAdviceCheckBox.isSelected()) {
            selectedAspects.append("Career advice\n, ");
        }
        if (personalDevelopmentCheckBox.isSelected()) {
            selectedAspects.append("Personal development\n, ");
        }
        return selectedAspects.length() > 0 ? selectedAspects.substring(0, selectedAspects.length() - 2) : "";
    }

    private void clearForm() {
        experienceLevelToggleGroup.selectToggle(null);
        networkingCheckBox.setSelected(false);
        learningSkillsCheckBox.setSelected(false);
        careerAdviceCheckBox.setSelected(false);
        personalDevelopmentCheckBox.setSelected(false);
        suggestionsTextArea.clear();
    }

    @FXML
    private void handleBackButtonAction() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/ProfilMentorView.fxml"));
            Parent mentorProfileView = loader.load();
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.getScene().setRoot(mentorProfileView);
        } catch (IOException e) {
            showAlert("Load Error", "Error loading mentor profile: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleViewProfileButtonAction(MentorData mentor) {
        Stage stage = (Stage) backButton.getScene().getWindow();
        if (stage != null) {
            HomepageController homepageController = (HomepageController) stage.getUserData();
            if (homepageController != null) {
                homepageController.switchToMentorProfile(mentor);
            } else {
                System.err.println("HomepageController is null. Please ensure it's properly set in the session.");
            }
        } else {
            System.err.println("Stage is null. Please check the stage initialization.");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showApprovalWaitAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Approval");
        alert.setHeaderText(null);
        alert.setContentText("Wait for mentor's approval");
        alert.showAndWait();
    }

    private void logError(String message) {
        System.err.println(message);
    }
}
