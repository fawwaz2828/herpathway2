package com.herpathway.controller;

import com.herpathway.session.SessionManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MenteeMenuController {

    @FXML
    private TableView<Questionnaire> questionnaireTable;

    @FXML
    private TableColumn<Questionnaire, Long> menteeIdColumn;

    @FXML
    private TableColumn<Questionnaire, String> experienceLevelColumn;

    @FXML
    private TableColumn<Questionnaire, String> beneficialAspectsColumn;

    @FXML
    private TableColumn<Questionnaire, String> suggestionsColumn;

    @FXML
    private TableColumn<Questionnaire, Void> viewColumn;

    private ObservableList<Questionnaire> questionnaireData;

    @FXML
    public void initialize() {
        menteeIdColumn.setCellValueFactory(new PropertyValueFactory<>("menteeId"));
        experienceLevelColumn.setCellValueFactory(new PropertyValueFactory<>("experienceLevel"));
        beneficialAspectsColumn.setCellValueFactory(new PropertyValueFactory<>("beneficialAspects"));
        suggestionsColumn.setCellValueFactory(new PropertyValueFactory<>("suggestions"));

        questionnaireData = FXCollections.observableArrayList();
        loadQuestionnaireData();

        questionnaireTable.setItems(questionnaireData);

        addButtonToTable();
    }

    private void loadQuestionnaireData() {
        long mentorId = SessionManager.getInstance().getCurrentUserId(); // Ambil ID mentor yang sedang login
        if (mentorId == 0) {
            System.out.println("ID mentor tidak ditemukan.");
            return;
        }

        String url = "jdbc:mysql://localhost:3306/herpath";
        String user = "root";
        String password = "mochimochi53";

        String query = "SELECT userIdMentee, experience_level_mentee, beneficial_aspects, suggestions FROM kuisioner WHERE userIdMentor = " + mentorId;

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                long menteeId = rs.getLong("userIdMentee");
                String experienceLevel = rs.getString("experience_level_mentee");
                String beneficialAspects = rs.getString("beneficial_aspects");
                String suggestions = rs.getString("suggestions");

                Questionnaire questionnaire = new Questionnaire(menteeId, experienceLevel, beneficialAspects, suggestions);
                questionnaireData.add(questionnaire);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addButtonToTable() {
        Callback<TableColumn<Questionnaire, Void>, TableCell<Questionnaire, Void>> cellFactory = new Callback<>() {
            @Override
            public TableCell<Questionnaire, Void> call(final TableColumn<Questionnaire, Void> param) {
                final TableCell<Questionnaire, Void> cell = new TableCell<>() {

                    private final Button btn = new Button("View");

                    {
                        btn.setOnAction(event -> {
                            Questionnaire data = getTableView().getItems().get(getIndex());
                            handleViewButtonAction(data);
                        });
                    }

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };

        viewColumn.setCellFactory(cellFactory);
    }

    private void handleViewButtonAction(Questionnaire questionnaire) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/herpathway/view/MenteeApplication.fxml"));
            Parent root = loader.load();

            MenteeApplicationController controller = loader.getController();
            controller.setMenteeId(questionnaire.getMenteeId());

            Stage stage = new Stage();
            stage.setTitle("Mentee Details");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static class Questionnaire {
        private long menteeId;
        private String experienceLevel;
        private String beneficialAspects;
        private String suggestions;

        public Questionnaire(long menteeId, String experienceLevel, String beneficialAspects, String suggestions) {
            this.menteeId = menteeId;
            this.experienceLevel = experienceLevel;
            this.beneficialAspects = beneficialAspects;
            this.suggestions = suggestions;
        }

        public long getMenteeId() {
            return menteeId;
        }

        public String getExperienceLevel() {
            return experienceLevel;
        }

        public String getBeneficialAspects() {
            return beneficialAspects;
        }

        public String getSuggestions() {
            return suggestions;
        }
    }
}
