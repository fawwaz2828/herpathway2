package com.herpathway.controller;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ControllerTeknologi implements Initializable {

    @FXML
    private AnchorPane shape1;
    
    @FXML
    private Text text3;

    @FXML
    private Text text1;

    @FXML
    private Button thread;

    @FXML
    private ImageView shape11;

    @FXML
    private ImageView shape2;

    @FXML
    private ImageView shape3;

    @FXML
    private ImageView shape4;

    @FXML
    private ImageView shape5;

    // Optional: You can define more @FXML variables for other elements

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialization code if needed
    }

    @FXML
    private void ClickDiscuss1() {
        try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("post.fxml"));
        Parent root = loader.load();

        Stage stage = new Stage();
        stage.setScene(new Scene(root));

        // Menutup scene saat ini (opsional, tergantung dari kebutuhan aplikasi Anda)
        Stage currentStage = (Stage) thread.getScene().getWindow();
        currentStage.close();

        stage.show();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    // Add more @FXML methods as needed for other actions

}
