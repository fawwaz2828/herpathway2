package com.herpathway.controller;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ControllerScience1 implements Initializable {

    @FXML
    private AnchorPane shape1;

    @FXML
    private Text text3;

    @FXML
    private Text text1;

    @FXML
    private Button thread;

    @FXML
    private ImageView shape11;

    @FXML
    private ImageView shape2;

    @FXML
    private ImageView shape3;

    @FXML
    private ImageView shape4;

    @FXML
    private ImageView shape5;

    @FXML
    private ImageView image2;

    @FXML
    private Circle circle;

    @FXML
    private Line line1;

    @FXML
    private Line line2;

    @FXML 
    private Button post;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialization code here
    }

    @FXML
    void ClickDiscuss(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("post.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));

            // Menutup scene saat ini (opsional, tergantung dari kebutuhan aplikasi Anda)
            Stage currentStage = (Stage) thread.getScene().getWindow();
            currentStage.close();

            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    private void handlePostButtonAction() {
        // Log for debug
        System.out.println("Back button clicked.");

        // Get the HomepageController from the window's userData
        Stage stage = (Stage) post.getScene().getWindow();
        if (stage != null) {
            System.out.println("Stage found.");
            HomepageController homepageController = (HomepageController) stage.getUserData();
            if (homepageController != null) {
                System.out.println("HomepageController found.");
                homepageController.switchToPost();
            } else {
                System.out.println("HomepageController not found.");
            }
        } else {
            System.out.println("Stage not found.");
        }
    }
    

}
