package com.herpathway.controller;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;

import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.herpathway.session.SessionManager;

public class MentorChatSessionController {

    @FXML
    private ListView<String> menteeListView;

    @FXML
    private TextArea chatArea;

    @FXML
    private TextField inputField;

    @FXML
    private VBox menteeProfileBox;

    @FXML
    private Label menteeNameLabel;

    @FXML
    private ImageView menteeProfileImage;

    @FXML
    private VBox mentorProfileBox;

    @FXML
    private Label mentorNameLabel;

    @FXML
    private ImageView mentorProfileImage;

    private long mentorId;
    private long menteeId;
    private long senderId;

    private PrintWriter out;
    private BufferedReader in;
    private Socket socket;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/herpath";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "mochimochi53";

    @FXML
    public void initialize() {
        this.mentorId = SessionManager.getInstance().getCurrentUserId();
        this.senderId = mentorId; // assuming the sender is always the mentor in this context
        loadMenteeList();
        connectToServer();
        loadMentorProfileData();
    }

    private void connectToServer() {
        try {
            socket = new Socket("localhost", 12345);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            new Thread(new IncomingMessageHandler()).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class IncomingMessageHandler implements Runnable {
        public void run() {
            try {
                String message;
                while ((message = in.readLine()) != null) {
                    final String receivedMessage = message;
                    System.out.println("Received message: " + receivedMessage);
                    Platform.runLater(() -> chatArea.appendText(receivedMessage + "\n"));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void loadMentorProfileData() {
        String sql = "SELECT * FROM form_Mentor WHERE userId = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setLong(1, mentorId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String displayName = rs.getString("displayName");
                byte[] profilePictureData = rs.getBytes("profilePicture");

                mentorNameLabel.setText(displayName);

                if (profilePictureData != null) {
                    Image profileImage = new Image(new ByteArrayInputStream(profilePictureData));
                    mentorProfileImage.setImage(profileImage);
                } else {
                    mentorProfileImage.setImage(null);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void setMentorId(long mentorId) {
        this.mentorId = mentorId;
        System.out.println("setMentorId called with mentorId: " + mentorId);
    }

    public void setMenteeId(long menteeId) {
        this.menteeId = menteeId;
        System.out.println("setMenteeId called with menteeId: " + menteeId);
        loadMenteeProfile();
        loadChatHistory();
    }

    public void setSenderId(long senderId) {
        this.senderId = senderId;
        System.out.println("setSenderId called with senderId: " + senderId);
    }

    public void loadChatHistory() {
        String query = "SELECT senderId, message FROM ChatSession WHERE menteeId = ? AND mentorId = ? ORDER BY timestamp";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setLong(1, menteeId);
            pstmt.setLong(2, mentorId);
            ResultSet rs = pstmt.executeQuery();

            Platform.runLater(() -> {
                try {
                    chatArea.clear();
                    while (rs.next()) {
                        long senderId = rs.getLong("senderId");
                        String message = rs.getString("message");
                        String sender = (senderId == MentorChatSessionController.this.senderId) ? "Mentor" : "Mentee";
                        chatArea.appendText(sender + ": " + message + "\n");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleSendButtonAction() {
        System.out.println("Send button clicked");

        // Print the current state of important fields
        System.out.println("senderId: " + senderId);
        System.out.println("menteeId: " + menteeId);
        System.out.println("mentorId: " + mentorId);
        System.out.println("inputField: " + (inputField != null ? inputField.getText() : "null"));

        if (senderId == 0 || menteeId == 0 || mentorId == 0 || inputField == null) {
            System.err.println("Error: One or more required fields are not initialized.");
            return;
        }

        String message = inputField.getText();
        System.out.println("Message to send: " + message);
        if (!message.isEmpty()) {
            long receiverId = (senderId == menteeId) ? mentorId : menteeId;
            saveMessage(senderId, receiverId, message);
            out.println("Mentor: " + message);
            inputField.clear();
        }
    }

    private void loadMenteeList() {
        String query = "SELECT userId, displayName FROM form_Mentee";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                long userId = rs.getLong("userId");
                String displayName = rs.getString("displayName");
                menteeListView.getItems().add(displayName + " (ID: " + userId + ")");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void saveMessage(long senderId, long receiverId, String message) {
        String query = "INSERT INTO ChatSession (menteeId, mentorId, senderId, receiverId, message, timestamp) VALUES (?, ?, ?, ?, ?, NOW())";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setLong(1, menteeId);
            pstmt.setLong(2, mentorId);
            pstmt.setLong(3, senderId);
            pstmt.setLong(4, receiverId);
            pstmt.setString(5, message);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Message saved successfully.");
            } else {
                System.err.println("Failed to save message.");
            }

        } catch (SQLException e) {
            System.err.println("Error saving message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadMenteeProfile() {
        String query = "SELECT displayName, profilePicture FROM form_Mentee WHERE userId = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setLong(1, menteeId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String displayName = rs.getString("displayName");
                byte[] profilePictureData = rs.getBytes("profilePicture");

                menteeNameLabel.setText(displayName);

                if (profilePictureData != null) {
                    Image profileImage = new Image(new ByteArrayInputStream(profilePictureData));
                    menteeProfileImage.setImage(profileImage);
                } else {
                    menteeProfileImage.setImage(null);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleMenteeSelection() {
        String selectedItem = menteeListView.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            String[] parts = selectedItem.split(" \\(ID: ");
            String displayName = parts[0];
            String idPart = parts[1].replace(")", "");
            menteeId = Long.parseLong(idPart);
            menteeNameLabel.setText(displayName);
            setMenteeId(menteeId);
        }
    }
}
