package com.herpathway.controller;

public class MentorshipGoalController {
    
}
