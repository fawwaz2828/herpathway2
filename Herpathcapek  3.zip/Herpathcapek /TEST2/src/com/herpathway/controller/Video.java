package com.herpathway.controller;


import javafx.fxml.FXML;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;

public class Video {

    @FXML
    private ScrollPane scrollPane;

    @FXML
    private ImageView imageView;

    // Initialize method is called after the FXML file is loaded
    @FXML
    private void initialize() {
        // You can add additional initialization logic here if needed
        System.out.println("FXML file is loaded and controller is initialized");

        // Example: Set a different image programmatically if needed
        // Image newImage = new Image("path/to/new/image.png");
        // imageView.setImage(newImage);
    }
}
