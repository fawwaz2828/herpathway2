package com.herpathway.controller;


import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ControllerThread2 {

    @FXML
    private AnchorPane anchorpane2;

    @FXML
    private AnchorPane pane1;

    @FXML
    private ImageView gambar1;

    @FXML
    private Text text1;

    @FXML
    private Text text2;

    @FXML
    private Text text3;

    @FXML
    private Text text4;

    @FXML
    private Text text5;

    @FXML
    private Text text6;

    @FXML
    private Text text7;

    @FXML
    private Text text8;

    @FXML
    private Text text9;

    @FXML
    private Text text10;

    @FXML
    private Line line1;

    @FXML
    private Line line2;

    @FXML
    private Circle line3;

    @FXML
    private Circle line4;

    @FXML
    private ImageView shape1;

    @FXML
    private ImageView shape2;

    @FXML
    private ImageView shape3;

    @FXML
    private ImageView shape4;

    @FXML
    private ImageView shape5;

    @FXML
    private ImageView shape6;

    @FXML
    private ImageView shape7;

    @FXML
    private ImageView shape8;

    @FXML
    private ImageView shape9;

    @FXML
    private ImageView shape10;

    @FXML
    private Button buttonForum;

    @FXML
    private Button buttonForum1;

    @FXML
    private void joinThread1(ActionEvent event) {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("science2.fxml"));
        Parent root = loader.load();

        Stage stage = new Stage();
        stage.setScene(new Scene(root));

        // Menutup scene saat ini (opsional, tergantung dari kebutuhan aplikasi Anda)
        Stage currentStage = (Stage) buttonForum.getScene().getWindow();
        currentStage.close();

        stage.show();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
@FXML
private void joinThread2(ActionEvent event) {
try {
    FXMLLoader loader = new FXMLLoader(getClass().getResource("teknologi2.fxml"));
    Parent root = loader.load();

    Stage stage = new Stage();
    stage.setScene(new Scene(root));

    // Menutup scene saat ini (opsional, tergantung dari kebutuhan aplikasi Anda)
    Stage currentStage = (Stage) buttonForum1.getScene().getWindow();
    currentStage.close();

    stage.show();
} catch (IOException e) {
    e.printStackTrace();
}
}
}
