package com.herpathway.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Button;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MenteeApplicationController {

    @FXML
    private Label displayNameLabel;
    @FXML
    private Label realNameLabel;
    @FXML
    private Label phoneNumberLabel;
    @FXML
    private Label emailLabel;
    @FXML
    private Label addressLabel;
    @FXML
    private Label instagramLabel;
    @FXML
    private Label linkedInLabel;
    @FXML
    private Label lastEducationLevelLabel;
    @FXML
    private Label educationalInstitutionLabel;
    @FXML
    private Label fieldOfStudyLabel;
    @FXML
    private Label graduationYearLabel;
    @FXML
    private Label currentJobLabel;
    @FXML
    private Label companyNameLabel;
    @FXML
    private Label positionLabel;
    @FXML
    private Label workExperienceLabel;
    @FXML
    private Label mainGoalLabel;
    @FXML
    private Label fieldOfStudyGoalLabel;
    @FXML
    private Label expectationsLabel;
    @FXML
    private Button acceptButton;

    private long menteeId;

    public void setMenteeId(long menteeId) {
        this.menteeId = menteeId;
        loadMenteeDetails();
    }

    private void loadMenteeDetails() {
        String url = "jdbc:mysql://localhost:3306/herpath";
        String user = "root";
        String password = "mochimochi53";

        String query = "SELECT * FROM form_Mentee WHERE userId = " + menteeId;

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                displayNameLabel.setText(rs.getString("displayName"));
                realNameLabel.setText(rs.getString("realName"));
                phoneNumberLabel.setText(rs.getString("phoneNumber"));
                emailLabel.setText(rs.getString("email"));
                addressLabel.setText(rs.getString("address"));
                instagramLabel.setText(rs.getString("instagram"));
                linkedInLabel.setText(rs.getString("linkedIn"));
                lastEducationLevelLabel.setText(rs.getString("lastEducationLevel"));
                educationalInstitutionLabel.setText(rs.getString("educationalInstitution"));
                fieldOfStudyLabel.setText(rs.getString("fieldOfStudy"));
                graduationYearLabel.setText(String.valueOf(rs.getInt("graduationYear")));
                currentJobLabel.setText(rs.getString("currentJob"));
                companyNameLabel.setText(rs.getString("companyName"));
                positionLabel.setText(rs.getString("position"));
                workExperienceLabel.setText(rs.getString("workExperience"));
                mainGoalLabel.setText(rs.getString("mainGoal"));
                fieldOfStudyGoalLabel.setText(rs.getString("fieldOfStudyGoal"));
                expectationsLabel.setText(rs.getString("expectations"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleAcceptButtonAction() {
        System.out.println("Accept button pressed");

        String url = "jdbc:mysql://localhost:3306/herpath";
        String user = "root";
        String password = "mochimochi53";

        String updateQuery = "UPDATE form_Mentee SET status = 'Accepted' WHERE userId = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {

            pstmt.setLong(1, menteeId);
            int rowsUpdated = pstmt.executeUpdate();
            System.out.println("Rows updated: " + rowsUpdated);

            if (rowsUpdated > 0) {
                // Setelah status diperbarui, alihkan mentor ke halaman chat session
                MentorHomepageController mentorHomepageController = MentorHomepageController.getInstance();
                if (mentorHomepageController != null) {
                    System.out.println("MentorHomepageController instance found");
                    mentorHomepageController.switchToChatSession(menteeId);
                } else {
                    System.out.println("MentorHomepageController instance not found");
                }

                // Arahkan mentee ke halaman chat session
                HomepageController menteeHomepageController = HomepageController.getInstance();
                if (menteeHomepageController != null) {
                    System.out.println("MenteeHomepageController instance found");
                    menteeHomepageController.switchToChatSession(menteeId);
                } else {
                    System.out.println("MenteeHomepageController instance not found");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
