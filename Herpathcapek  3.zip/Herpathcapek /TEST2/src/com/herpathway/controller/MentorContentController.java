package com.herpathway.controller;


import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;

public class MentorContentController {
    @FXML
    private ImageView imageView;

    @FXML
    private ImageView imageView1;

    @FXML
    private ImageView imageView11;

    @FXML
    private void handleButtonAction(ActionEvent event) {
        Button clickedButton = (Button) event.getSource();
        String buttonText = clickedButton.getText();

        switch (buttonText) {
            case "Article":
                Image articleImage = new Image(getClass().getResource("/image/article.png").toExternalForm());
                imageView.setImage(articleImage);
                break;
            case "Video":
                Image videoImage = new Image(getClass().getResource("/image/video-player.png").toExternalForm());
                imageView1.setImage(videoImage);
                break;
            case "E-book":
                Image ebookImage = new Image(getClass().getResource("/image/books-stack-of-three.png").toExternalForm());
                imageView11.setImage(ebookImage);
                break;
            default:
                break;
        }
    }
}