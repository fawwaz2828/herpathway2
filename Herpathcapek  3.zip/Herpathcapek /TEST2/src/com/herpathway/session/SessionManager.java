package com.herpathway.session;

import com.herpathway.model.MentorData;

public class SessionManager {
    private static SessionManager instance;
    private long currentUserId;
    private String currentUserUsername;
    private MentorData currentMentorData;

    private SessionManager() {
    }

    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public void setCurrentUser(long userId, String username) {
        this.currentUserId = userId;
        this.currentUserUsername = username;
    }

    public long getCurrentUserId() {
        return currentUserId;
    }

    public String getCurrentUserUsername() {
        return currentUserUsername;
    }

    public MentorData getCurrentMentorData() {
        return currentMentorData;
    }

    public void setCurrentMentorData(MentorData currentMentorData) {
        this.currentMentorData = currentMentorData;
    }

    public long getCurrentMentorId() {
        if (currentMentorData != null) {
            return currentMentorData.getUserId();
        }
        return 0;
    }
}
